#!/usr/bin/env bash
set -x
export LD_LIBRARY_PATH=$LDLIBRARY_PATH:/usr/lib/hadoop/lib/native
#spark-submit \
./spark-1.6.1-bin-hadoop2.6/bin/spark-submit \
--class com.cmcm.push_up.App \
--conf spark.task.maxFailures=100 \
--conf spark.yarn.max.executor.failures=200 \
--master yarn-cluster \
--conf spark.rdd.compress=true \
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
--conf spark.yarn.executor.memoryOverhead=5120 \
--driver-memory 4g \
--executor-memory $( printf "%.0fM" $(bc -l <<< "24576*0.95-5120") ) \
--executor-cores 4 \
--queue offline \
--num-executors 40 \
push_up-1.0-SNAPSHOT-jar-with-dependencies.jar $@

#export SPARK_HOME=/home/news_push/pingjiangLi/spark-1.6.1-bin-hadoop2.6

#/user/news_db/archive/spark-1.6.1-bin-hadoop2.6
#sh run.sh 20170602 02 /projects/news/push/meerkat/raw_data/gcm_log/20170602 /projects/news/push/meerkat/raw_data/gcm_response/20170602/02 /projects/news/data/format_data_new/impression/20170602/02/00 /projects/news/push/meerkat/offline/all_user_region_1h/20170602/02.bz2/ /projects/news/push/meerkat/raw_data/push_msg/20170602/02 /projects/news/push/meerkat/offline/push_up_dev_1h/20170602/01/output /projects/news/push/meerkat/offline/push_up_dev_1h/20170602/02/output





#!/bin/bash

#pipeline_name=${PWD##*/}
workflows_dir=/user/news_push/pipelines
#echo $pipeline_name
#hadoop fs -rm -r -skipTrash ${workflows_dir}/${pipeline_name}
rm push_up-1.0-SNAPSHOT-jar-with-dependencies.jar
cp ../../../target/push_up-1.0-SNAPSHOT-jar-with-dependencies.jar push_up-1.0-SNAPSHOT-jar-with-dependencies.jar
hadoop fs -rm -r -skipTrash ${workflows_dir}
hadoop fs -mkdir -p ${workflows_dir}
hadoop fs -put . ${workflows_dir}

oozie job --config coordinator.properties -run
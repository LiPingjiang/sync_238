package com.cmcm.push_up

import java.io.InputStream
import java.text.SimpleDateFormat

import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StructType, _}
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.control.Breaks._


/**
  * Created by pingjiangli on 31/05/2017.
  */
object App {
  def main(args: Array[String]) {

    println("input arguments:")
    for(arg <- args){
      println(arg)
    }
    println("end, args length: " + args.length)

    if (args.length != 9) {
      System.err.println("Usage(4 agruments): push_up <date> <hour> <prev_date> <prev_hour>")
      System.exit(1)
    }

    println("args.length: " + args.length)
    val date = args(0)
    val hour = args(1)
    val gcm_log_path = args(2)
    val gcm_response_path = args(3)
    val impression_path = args(4)
    val prev_impression_path = args(5)
    val push_msg_path = args(6)
    val prev_output_path = args(7)
    val output_path= args(8)

    println("date -->" + date)
    println("hour -->" + hour)
    println("gcm_log_path -->" + gcm_log_path)
    println("gcm_response_path -->" + gcm_response_path)
    println("impression_path -->" + impression_path)
    println("prev_impression_path -->" + prev_impression_path)
    println("push_msg_path -->" + push_msg_path)



    val conf = new SparkConf().setAppName("PUSH_UP")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)

    println("SparkContext version: "+ sc.version)
    println("Scala version: "+ scala.tools.nsc.Properties.versionString)

    var mcc_map = Map[String,String]()
    val mcc_file = "/mcc_country.txt"
    val mcc_stream : InputStream = getClass.getResourceAsStream(mcc_file)
    for (line <- Source.fromInputStream( mcc_stream ).getLines) {
//      println(line)
      if(line.trim().split(",").length == 3){
        val mcc = line.trim().split(",")(0)
        val country = line.trim().split(",")(1)
        mcc_map += ( mcc -> country)
      }
    }
    var tz_map: Map[String, String] = Map[String,String]()
    val tz_file = "/tz.info"
    val tz_stream : InputStream = getClass.getResourceAsStream(tz_file)
    for (line <- Source.fromInputStream( tz_stream ).getLines) {
//      println(line)
      if(line.trim().split("\t").length == 2){
        val region = line.trim().split("\t")(0)
        val timezone = line.trim().split("\t")(1)
        tz_map += ( region -> timezone)
      }
    }
    def get_timezone(region:String): String = {
      if(tz_map.contains(region.toLowerCase))
        tz_map(region.toLowerCase)
      else
        "unknown"
    }
    def hour_to_current (timestamp:String) : Int = {
      val time = timestamp.toLong
      val current = new SimpleDateFormat("yyyyMMdd HH:mm").parse(date+" "+hour+":00").getTime()/1000
      ((current-time)/60/60).toInt
    }
    def url_decode(str:String): String = {
      var data = str.replaceAll("%(?![0-9a-fA-F]{2})", "%25")
      data = data.replaceAll("\\+", "%2B")
      java.net.URLDecoder.decode(data, "UTF-8")
    }
    val name_pid_dict = Map(
      "khcleanmaster" -> "1",
      "cmb" -> "2",
      "cmbrowser" -> "3",
      "cmlocker" -> "6",
      "cmlauncher" -> "7",
      "security" -> "9",
      "india_news" -> "11",
      "news_republic" -> "14",
      "nr_us" -> "17")

    def get_region (log_map:Map[String,String]) : String = {
      var region_android = ""

      if (log_map.contains("country")){
        region_android = log_map("country")
      }else if ( log_map.contains("mcc") && mcc_map.contains(log_map("mcc")) ){
        region_android = mcc_map(log_map("mcc"))
      }

      if (log_map.contains("cm_lan") && log_map("cm_lan") != "" ){
        val cm_fields = log_map("cm_lan").split("_")
        if (cm_fields.length == 2 && cm_fields(1) != ""){
          region_android = cm_fields(1).toLowerCase()
        }else{
          region_android = cm_fields(0) + "_" + region_android
        }
      }else if (log_map.contains("cl") && log_map("cl") != "" ){
        val cl_fields = log_map("cl").split("_")
        if (cl_fields.length == 2 && cl_fields(0) != "" && cl_fields(1) != ""){
          region_android = cl_fields(1).toLowerCase() + "_"+ cl_fields(0).toLowerCase()
        }else if ( log_map.contains("phonelanguage") && log_map("phonelanguage") != "" && log_map("phonelanguage").toLowerCase().split("_").length>1 ){
          region_android = log_map("phonelanguage").toLowerCase().split("_")(0) + "_" + region_android
        }else{
          region_android = "unknown"
        }
      }else{
        region_android = "unknown"
      }

      var region_ios = ""
      if( log_map.contains("lan") && log_map("lan") != ""){
        region_ios = log_map("lan").replace("-","_").toLowerCase().stripPrefix("_ ").stripSuffix("_ ")
      }else{
        region_ios = "unknown"
      }

      if (log_map.contains("lan") && (log_map("lan") contains "ios") )
        region_ios.trim
      else
        region_android.trim
    }



    def process_gcm_log (line:String,type_list: List[String]) : Option[Map[String,String]] = {

      val report_device_list: List[String] = List("/rpc/gcm/report", "/rpc/report/device")
      val click_view_list: List[String] = List("/rpc/taskback/gcm")

      for (log_type <- type_list) {
        if (line contains log_type){
          var gcm_log_map:Map[String,String] = Map()
          val log = line.trim

          val time_start = log.indexOfSlice("[")
          val time_end = log.indexOfSlice("]")
          val local_time_str = log.slice(time_start + 1, time_end - 6)
          val timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(local_time_str).getTime/1000
          gcm_log_map += ("timestamp" -> timestamp.toString)

          val ip_start = log.indexOfSlice("-") + 2
          val ip_end = log.indexOfSlice("-",ip_start) -1
          val ip_str = log.slice(ip_start,ip_end)
          gcm_log_map += ("ip" -> ip_str)

          val data_str_start = log.indexOfSlice(log_type) + log_type.length()
          val data_str_end = log.indexOfSlice("- ", data_str_start) -1
          val data_str = log.slice(data_str_start,data_str_end).trim
          val items = data_str.split("&")
          for(item <- items){
            val fields = item.split("=")
            if (fields.length == 2){
              val key = fields(0).replace(" ","").replace("?", "").replace("\\","").replace("/","")
              gcm_log_map += ( key -> fields(1))
            }
          }

          if(!gcm_log_map.contains("appflag") || !gcm_log_map.contains("aid")){
            return None
          }
          if(report_device_list.contains(log_type)){
            val key_list: List[String] = List("dataversion","devicetoken","msgid","lan","manufacture",
              "ip","apkversion","sdkversion","channel","regid","timezone")

            for (k <- key_list){
              if(!gcm_log_map.contains(k))
                gcm_log_map += (k -> "unknown")
            }
            if ((gcm_log_map("appflag") != "nr_us_ios" && gcm_log_map("appflag") != "nr_gb_ios" && gcm_log_map.contains("aid") && gcm_log_map("aid") != "" && gcm_log_map.contains("regid") && gcm_log_map("regid") != "" ) ||
              ( (gcm_log_map("appflag") == "nr_us_ios" || gcm_log_map("appflag") == "nr_gb_ios") && gcm_log_map.contains("deviceuid") && (gcm_log_map("deviceuid") != "") && gcm_log_map.contains("devicetoken") && (gcm_log_map("deviceuid") contains ".*null.*"))  ) {
              return Some(gcm_log_map)
            }
            else{
              return None
            }
          }else if(click_view_list.contains(log_type)){
            val key_list: List[String] = List("aid","action","pushid","timestamp")

            for (k <- key_list){
              if(!gcm_log_map.contains(k))
                gcm_log_map += (k -> "unknown")
            }
            return Some(gcm_log_map)
          }

        }
      }
      return None
    }


    val log_list = new ListBuffer[(String, String, String, String, String, String, String, String, String, String, String, String, String)]()

    val gcm_log_raw_schema =
      StructType(
        StructField("pid", StringType, true) ::
          StructField("ip", StringType, true) ::
          StructField("region", StringType, true) ::
          StructField("aid", StringType, true) ::
          StructField("timezone", StringType, true) ::
          StructField("apkversion", StringType, true) ::
          StructField("dataversion", StringType, true) ::
          StructField("sdkversion", StringType, true) ::
          StructField("manufacture", StringType, true) ::
          StructField("regid", StringType, true) ::
          StructField("msgid", StringType, true) ::
          StructField("channel", StringType, true) ::
          Nil)

    val gcm_log_file = sc.textFile(gcm_log_path)
    val gcm_log_raw_rdd = gcm_log_file.map({x=>
      val result = process_gcm_log(x,List("/rpc/gcm/report", "/rpc/report/device"))
      if (result != None){
        val log_map = result.get
        Row(if (name_pid_dict.contains(log_map("appflag"))) name_pid_dict(log_map("appflag")) else "unknown",log_map("ip"),get_region( log_map ),log_map("aid"),get_timezone(url_decode(log_map("timezone"))),log_map("apkversion"),log_map("dataversion"),log_map("sdkversion"),log_map("manufacture"),url_decode(log_map("regid")),log_map("msgid"),log_map("channel"))
      } else {
        Row()
      }
    }).filter( _.length > 0)


    val gcm_log_df = sqlContext.createDataFrame(gcm_log_raw_rdd.filter(_.length == 12), gcm_log_raw_schema).filter("pid != 'unknown'").select("pid","ip","region","aid","regid","apkversion","sdkversion","dataversion","manufacture","timezone","msgid","channel")


    val gcm_response_file = sc.textFile(gcm_response_path)
    val gcm_response_df = sqlContext.createDataFrame(gcm_response_file.map(_.split("\t") match { case Array(a, b, c, d, e) => (if (name_pid_dict.contains(a)) name_pid_dict(a) else "unknown", b, c, d, e)})).toDF("pid","region","aid","regid","timestamp").filter("pid != 'unknown'")


    val impression_file = sc.textFile(impression_path)

    def impression_get_data (row:String) : Tuple4[String,String,String,String] = {
      val r_a = row.split("\t")
      if(r_a.length > 33)
        return (r_a(20),r_a(1),r_a(30)+"_"+r_a(33).toLowerCase(),r_a(24))
      else
        return ("unknown","unknown","unknown","unknown")
    }

    //TODO: change to our version
    val prev_impression_df = sqlContext.createDataFrame(sc.textFile(prev_impression_path).map(_.split("\t") match { case Array(a, b, c, d) => (if (name_pid_dict.contains(a)) name_pid_dict(a) else "unknown", b, c, d); case _ => ("unknown","unknown","unknown","unknown") })).toDF("pid","aid","regid","timestamp").filter("pid != 'unknown'")

    val impression_schema =
      StructType(
        StructField("pid", StringType, true) ::
          StructField("aid", StringType, true) ::
          StructField("region", StringType, true) ::
          StructField("timestamp", StringType, true) ::
          Nil)

    val impression_rdd = sqlContext.createDataFrame(impression_file.map(impression_get_data(_))).toDF("pid","aid","region","timestamp").filter("aid != 'unknown'").union(prev_impression_df).
      filter("not region  RLIKE '.*unknown.*' ").orderBy(desc("timestamp")).groupBy("pid","aid").agg(
      collect_list("region") as "region",
      collect_list("timestamp") as "timestamp"
    ).rdd.map(x => {
      var region = "unknown"
      breakable { x.getAs[Seq[String]]("region").foreach( y => if( y != "unknown" ){ region = y;break })}
      var timestamp = "unknown"
      breakable { x.getAs[Seq[String]]("timestamp").foreach( y => if( y != "unknown" ){ timestamp = y;break })}

      Row(x.getAs[String]("pid"),x.getAs[String]("aid"),region,timestamp)
    })

    val impression_df = sqlContext.createDataFrame(impression_rdd , impression_schema).distinct


    val union_df_raw = gcm_log_df.select(			"pid",                  "region",                     "aid",                    "regid",                        "ip", 						          "timezone", 						            "apkversion", 						          "dataversion", 					 	            "sdkversion", 						          "manufacture", 						            "msgid",						            "channel").
      union(gcm_response_df.select(	          gcm_response_df("pid"),  gcm_response_df("region"),   gcm_response_df("aid"),   gcm_response_df("regid"), 	    lit("unknown").alias("ip"), lit("unknown").alias("timezone"), 	lit("unknown").alias("apkversion"), lit("unknown").alias("dataversion"), 	lit("unknown").alias("sdkversion"), lit("unknown").alias("manufacture"), 	lit("unknown").alias("msgid"),	lit("unknown").alias("channel"))).
      union(impression_df.select(		          impression_df("pid"),    impression_df("region"),     impression_df("aid"),     lit("unknown").alias("regid"), 	lit("unknown").alias("ip"), lit("unknown").alias("timezone"), 	lit("unknown").alias("apkversion"), lit("unknown").alias("dataversion"), 	lit("unknown").alias("sdkversion"), lit("unknown").alias("manufacture"), 	lit("unknown").alias("msgid"),	lit("unknown").alias("channel"))).
      filter("regid != 'unknown' and regid IS NOT NULL and aid !='unknown' and aid IS NOT NULL")

    val union_df_result=union_df_raw.groupBy("pid","aid").agg(
      collect_set("region") as "region",
      collect_set("regid") as "regid",
      collect_set("ip") as "ip",
      collect_set("timezone") as "timezone",
      collect_set("apkversion") as "apkversion",
      collect_set("dataversion") as "dataversion",
      collect_set("sdkversion") as "sdkversion",
      collect_set("manufacture") as "manufacture",
      collect_set("msgid") as "msgid",
      collect_set("channel") as "channel"
    )

    val union_df_comb = union_df_result.rdd.map(x => {
      var region = "unknown"
      breakable { x.getAs[Seq[String]]("region").foreach( y => if( y != "unknown" ){ region = y;break })}
      var regid = "unknown"
      breakable { x.getAs[Seq[String]]("regid").foreach( y => if( y != "unknown" ){ regid = y;break })}
      var ip = "unknown"
      breakable { x.getAs[Seq[String]]("ip").foreach( y => if( y != "unknown" ){ ip = y;break })}
      var timezone = "unknown"
      breakable { x.getAs[Seq[String]]("timezone").foreach( y => if( y != "unknown" ){ timezone = y;break })}
      var apkversion = "unknown"
      breakable { x.getAs[Seq[String]]("apkversion").foreach( y => if( y != "unknown" ){ apkversion = y;break })}
      var dataversion = "unknown"
      breakable { x.getAs[Seq[String]]("dataversion").foreach( y => if( y != "unknown" ){ dataversion = y;break })}
      var sdkversion = "unknown"
      breakable { x.getAs[Seq[String]]("sdkversion").foreach( y => if( y != "unknown" ){ sdkversion = y;break })}
      var manufacture = "unknown"
      breakable { x.getAs[Seq[String]]("manufacture").foreach( y => if( y != "unknown" ){ manufacture = y;break })}
      var msgid = "unknown"
      breakable { x.getAs[Seq[String]]("msgid").foreach( y => if( y != "unknown" ){ msgid = y;break })}
      var channel = "unknown"
      breakable { x.getAs[Seq[String]]("channel").foreach( y => if( y != "unknown" ){ channel = y;break })}
      Row(x.getAs[String]("pid"),x.getAs[String]("aid"),region,regid,ip,timezone,apkversion,dataversion,sdkversion,manufacture,msgid,channel)
    })

    val union_df_comb_schema = StructType(
      StructField("pid", StringType, true) ::
        StructField("aid", StringType, true) ::
        StructField("region", StringType, true) ::
        StructField("regid", StringType, true) ::
        StructField("ip", StringType, true) ::
        StructField("timezone", StringType, true) ::
        StructField("apkversion", StringType, true) ::
        StructField("dataversion", StringType, true) ::
        StructField("sdkversion", StringType, true) ::
        StructField("manufacture", StringType, true) ::
        StructField("msgid", StringType, true) ::
        StructField("channel", StringType, true) ::
        Nil)


    val union_df = sqlContext.createDataFrame(union_df_comb.filter(_.length == 12), union_df_comb_schema).filter("pid != 'unknown'")

    val gcm_click_view_schema =
      StructType(
        StructField("pid", StringType, true) ::
          StructField("aid", StringType, true) ::
          StructField("action", StringType, true) ::
          StructField("pushid", StringType, true) ::
          StructField("timestamp", StringType, true) ::
          Nil)

    val gcm_click_view_rdd = gcm_log_file.map({x=>{
      val result = process_gcm_log(x,List("/rpc/taskback/gcm"))
      if (result != None){
        val log_map = result.get
        Row(if (name_pid_dict.contains(log_map("appflag"))) name_pid_dict(log_map("appflag")) else "unknown",log_map("aid"), log_map("action"),log_map("pushid"),log_map("timestamp"))
      }else {
        Row()
      }
    }}).filter( _.length > 0)

    val gcm_click_view_df = sqlContext.createDataFrame(gcm_click_view_rdd.filter(_.length == 5), gcm_click_view_schema).filter("pid != 'unknown'").
      filter("action is not null and action != 'unknown' and pushid is not null and pushid != 'unknown' and aid is not null and aid != 'unknown'")

    val push_msg_file = sc.textFile(push_msg_path)
    val push_msg_df_raw = sqlContext.createDataFrame(push_msg_file.map(x => x.split("\t")).filter( _.length == 11 ).map(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(x(9)).getTime()/1000, x(10)))).toDF("pushid","cid","batch_id","push_num","expid","lan","country","pid","audience_num","timestamp","obj").filter("pid != 'unknown'")

    val push_msg_rdd = push_msg_df_raw.select("pushid","pid","cid","timestamp").groupBy("pushid","pid").agg(
      collect_list("cid") as "cid",
      collect_list("timestamp") as "timestamp"
    ).rdd.map(x => {
      val cid = x.getAs[Seq[String]]("cid")
      val timestamp = x.getAs[Seq[Long]]("timestamp")
      var cid_map:Map[String,String] = Map()
      cid.foreach({ x =>
        val time = timestamp(cid.indexOf(x))
        if (hour_to_current(time.toString) <= 24*7 && x != "unknown") {
          cid_map += (x -> time.toString)
        }
      })
      Row(x.getAs[String]("pushid"),x.getAs[String]("pid"),cid_map)
    })

    val push_msg_schema =
      StructType(
        StructField("pushid", StringType, true) ::
          StructField("pid", StringType, true) ::
          StructField("cid_timestamp", DataTypes.createMapType(StringType, StringType), true) ::
          Nil)
    val push_msg_df = sqlContext.createDataFrame(push_msg_rdd.filter(_.length == 3), push_msg_schema)

    val click_view_list = gcm_click_view_df.orderBy(desc("timestamp")).groupBy("pid","aid","pushid").agg(
      collect_list("action") as "action",
      collect_list("timestamp") as "timestamp"
    )

    val click_view_comb = click_view_list.rdd.map(x => {

      val action = x.getAs[Seq[String]]("action")
      val timestamp = x.getAs[Seq[String]]("timestamp")
      var clikc_count = 0
      var view_count = 0
      var last_view_timestamp:Long = 0

      action.foreach({ x =>
        val time = timestamp(action.indexOf(x))
        if (hour_to_current(time) <= 24) {
          x match {
            case "2" => {clikc_count +=1 }
            case "5" => {view_count +=1; if (time.toLong > last_view_timestamp) last_view_timestamp = time.toLong }
            case _ => {}
          }
        }
      })
      if(clikc_count == 0 && view_count==0 )
        Row()
      else
        Row(x.getAs[String]("pid"),x.getAs[String]("aid"),x.getAs[String]("pushid"),clikc_count.toString,view_count.toString,last_view_timestamp.toString)
    }).filter( _.length > 0)

    val click_view_comb_schema =
      StructType(
        StructField("pid", StringType, true) ::
          StructField("aid", StringType, true) ::
          StructField("pushid", StringType, true) ::
          StructField("clikc_count", StringType, true) ::
          StructField("view_count", StringType, true) ::
          StructField("last_view_timestamp", StringType, true) ::
          Nil)

    val click_view_comb_df = sqlContext.createDataFrame(click_view_comb.filter(_.length == 6), click_view_comb_schema).distinct

    val click_view_df = click_view_comb_df.join(push_msg_df, Seq( "pid","pushid"), "left_outer")//.select("pid","aid","clikc_count","view_count","last_view_timestamp","cid_timestamp")

    val push_up_df = union_df.join(click_view_df,Seq("pid", "aid"), "left_outer")


    val output_df_current = push_up_df.select(push_up_df("pid"),push_up_df("aid"),push_up_df("region"),push_up_df("regid"),push_up_df("ip"),push_up_df("timezone"),push_up_df("apkversion"),push_up_df("dataversion"),push_up_df("sdkversion"),push_up_df("manufacture"),push_up_df("channel"),push_up_df("clikc_count"),push_up_df("view_count"),push_up_df("last_view_timestamp"),push_up_df("cid_timestamp"),lit("unknown").alias("is_new_user"),lit(null).cast(MapType(StringType, StringType)).alias("viewed_categories"),lit(null).cast(MapType(StringType, StringType)).alias("click_categories"))

    val prev_output_df = sqlContext.read.format("parquet").load(prev_output_path)

    val output_df_union = output_df_current.union(prev_output_df)//as cid_timestamp is map, cannot distinct

    val output_df_string = output_df_union.select("pid","aid","region","regid","ip","timezone","apkversion","dataversion","sdkversion","manufacture","channel","clikc_count","view_count","last_view_timestamp","is_new_user").distinct
    val output_df_cidtimestamp = output_df_union.select(output_df_union("pid"),output_df_union("aid"),explode(output_df_union("cid_timestamp"))).distinct


    val output_df_raw = sqlContext.createDataFrame(output_df_string.
      groupBy("aid","pid").
      agg(
        collect_list("region") as "region",
        collect_list("regid") as "regid",
        collect_list("ip") as "ip",
        collect_list("timezone") as "timezone",
        collect_list("apkversion") as "apkversion",
        collect_list("dataversion") as "dataversion",
        collect_list("sdkversion") as "sdkversion",
        collect_list("manufacture") as "manufacture",
        collect_list("channel") as "channel",
        collect_list("clikc_count") as "clikc_count",
        collect_list("view_count") as "view_count",
        collect_list("last_view_timestamp") as "last_view_timestamp",
        collect_list("is_new_user") as "is_new_user"
      ).rdd.map(x => {
      var region = "unknown"
      breakable { x.getAs[Seq[String]]("region").foreach( y => if( y != "unknown" ){ region = y;break })}
      var regid = "unknown"
      breakable { x.getAs[Seq[String]]("regid").foreach( y => if( y != "unknown" ){ regid = y;break })}
      var ip = "unknown"
      breakable { x.getAs[Seq[String]]("ip").foreach( y => if( y != "unknown" ){ ip = y;break })}
      var timezone = "unknown"
      breakable { x.getAs[Seq[String]]("timezone").foreach( y => if( y != "unknown" ){ timezone = y;break })}
      var apkversion = "unknown"
      breakable { x.getAs[Seq[String]]("apkversion").foreach( y => if( y != "unknown" ){ apkversion = y;break })}
      var dataversion = "unknown"
      breakable { x.getAs[Seq[String]]("dataversion").foreach( y => if( y != "unknown" ){ dataversion = y;break })}
      var sdkversion = "unknown"
      breakable { x.getAs[Seq[String]]("sdkversion").foreach( y => if( y != "unknown" ){ sdkversion = y;break })}
      var manufacture = "unknown"
      breakable { x.getAs[Seq[String]]("manufacture").foreach( y => if( y != "unknown" ){ manufacture = y;break })}
      var channel = "unknown"
      breakable { x.getAs[Seq[String]]("channel").foreach( y => if( y != "unknown" ){ channel = y;break })}
      var clikc_count = "unknown"
      breakable { x.getAs[Seq[String]]("clikc_count").foreach( y => if( y != "unknown" ){ clikc_count = y;break })}
      var view_count = "unknown"
      breakable { x.getAs[Seq[String]]("view_count").foreach( y => if( y != "unknown" ){ view_count = y;break })}
      var last_view_timestamp = "unknown"
      breakable { x.getAs[Seq[String]]("last_view_timestamp").foreach( y => if( y != "unknown" ){ last_view_timestamp = y;break })}
      var is_new_user = "unknown"
      breakable { x.getAs[Seq[String]]("is_new_user").foreach( y => if( y != "unknown" ){ is_new_user = y;break })}
      //      var viewed_categories = "unknown"
      //      breakable { x.getAs[Seq[String]]("viewed_categories").foreach( y => if( y != "unknown" ){ viewed_categories = y;break })}
      //      var click_categories = "unknown"
      //      breakable { x.getAs[Seq[String]]("click_categories").foreach( y => if( y != "unknown" ){ click_categories = y;break })}

      (x.getAs[String]("pid"),x.getAs[String]("aid"),region,regid,ip,timezone,apkversion,dataversion,sdkversion,manufacture,channel,
        clikc_count,view_count,last_view_timestamp,is_new_user)//add all
    })).toDF("pid", "aid","region","regid","ip","timezone","apkversion","dataversion","sdkversion","manufacture","channel","clikc_count","view_count","last_view_timestamp","is_new_user").
      join(sqlContext.createDataFrame(output_df_cidtimestamp.groupBy("aid","pid"
      ).agg(collect_list("key") as "cid",collect_list("value") as "time"
      ).rdd.map(x => {
        var cid_timestamp = Map[String,String]()
        val cid =x.getAs[Seq[String]]("cid")
        val time =x.getAs[Seq[String]]("time")
        time.foreach( y => {
          val c = cid(time.indexOf(y))
          if (hour_to_current(y.toString) <= 24*7 && c != "unknown") {
            cid_timestamp += (c -> y.toString)
          }
        })
        (x.getAs[String]("pid"),x.getAs[String]("aid"),cid_timestamp)
      })).toDF("pid", "aid","cid_timestamp")
        ,Seq("pid","aid"),"left_outer")

    val output_df = output_df_raw.select(output_df_raw("pid"), output_df_raw("aid"),output_df_raw("region"),output_df_raw("regid"),output_df_raw("ip"),output_df_raw("timezone"),output_df_raw("apkversion"),output_df_raw("dataversion"),output_df_raw("sdkversion"),output_df_raw("manufacture"),output_df_raw("channel"),output_df_raw("clikc_count"),output_df_raw("view_count"),output_df_raw("last_view_timestamp"),output_df_raw("cid_timestamp"),output_df_raw("is_new_user"),lit(null).cast(MapType(StringType, StringType)).alias("viewed_categories"),lit(null).cast(MapType(StringType, StringType)).alias("click_categories"))

    output_df.write.parquet(output_path)


  }

}

#!/usr/bin/env bash
 set -x
 export LD_LIBRARY_PATH=$LDLIBRARY_PATH:/usr/lib/hadoop/lib/native
 spark-submit \
 --class com.cmcm.push_up.App \
 --conf spark.task.maxFailures=200 \
 --conf spark.yarn.max.executor.failures=400 \
 --master yarn-cluster \
 --conf spark.rdd.compress=true \
 --conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
 --conf spark.yarn.executor.memoryOverhead=5120 \
 --driver-memory 4g \
 --executor-memory $( printf "%.0fM" $(bc -l <<< "24576*0.95-5120") ) \
 --executor-cores 4 \
 --queue offline \
 --num-executors 50 \
 push-up.jar $@